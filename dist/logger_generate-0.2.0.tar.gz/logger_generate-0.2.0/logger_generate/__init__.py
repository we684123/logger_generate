from logger_generate.logger_generate import generate
